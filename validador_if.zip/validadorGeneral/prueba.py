dragon = "Gorila"

if 3 > 2:
    print("Ha entrado en el if correctamente")
elif 3 == 0:
    print("NO PUEDE ENTRAR AQUI")
    pass
else: 
    pass

def tratamiento():
    pass

if dragon == "Comodo":
    pass

if 3 > 2:
    print("Ha entrado en el if correctamente" + str(dragon))
    pass
elif 3 == 0:
    print("NO PUEDE ENTRAR AQUI")
    pass
else:
    pass